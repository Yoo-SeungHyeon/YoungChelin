package YoungCheline.YoungCheline;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class YoungChelineApplicationTests {

	@Test
	void contextLoads() {
	}

}
