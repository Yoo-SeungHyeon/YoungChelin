## 실행 환경 설정 & 코드 실행법

1. https://nodejs.org/en 사이트에 접속하여 NodeJS LTS 버전 설치(특별한 설정 없이 모두 다음 클릭 후 설치 완료)
2. 터미널에 node -v 명령어 입력하여 버전이 출력되는지 확인
3. 프로젝트 폴더 경로에서 npm install && npm run build && npm start 명령어 실행 후 브라우저 주소창에 http://localhost:3000 입력 후 엔터
