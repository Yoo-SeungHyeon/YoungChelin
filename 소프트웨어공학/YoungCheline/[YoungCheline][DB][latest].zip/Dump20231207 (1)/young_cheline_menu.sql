-- MySQL dump 10.13  Distrib 8.0.33, for macos13 (arm64)
--
-- Host: 0.0.0.0    Database: young_cheline
-- ------------------------------------------------------
-- Server version	8.0.33

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `menu`
--

DROP TABLE IF EXISTS `menu`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `menu` (
  `menu_id` int NOT NULL AUTO_INCREMENT,
  `menu_name` varchar(255) DEFAULT NULL,
  `restaurant_id` varchar(255) DEFAULT NULL,
  `url` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`menu_id`)
) ENGINE=InnoDB AUTO_INCREMENT=39 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `menu`
--

LOCK TABLES `menu` WRITE;
/*!40000 ALTER TABLE `menu` DISABLE KEYS */;
INSERT INTO `menu` VALUES (1,'대창덮밥','1883770159','https://youngcheline.s3.ap-northeast-2.amazonaws.com/%EB%8C%80%EC%B0%BD%EB%8D%AE%EB%B0%A5.jpg'),(2,'뚝배기','15752650','https://youngcheline.s3.ap-northeast-2.amazonaws.com/%EB%9A%9D%EB%B0%B0%EA%B8%B0.jpg'),(3,'꿀갈비비빔밥','714569417','https://youngcheline.s3.ap-northeast-2.amazonaws.com/%EA%BF%80%EA%B0%88%EB%B9%84.jpg'),(4,'돼지국밥','11385265','https://youngcheline.s3.ap-northeast-2.amazonaws.com/%EB%8F%BC%EC%A7%80%EA%B5%AD%EB%B0%A5.jpg'),(5,'삼겹살','287757696','https://youngcheline.s3.ap-northeast-2.amazonaws.com/%EC%82%BC%EA%B2%B9%EC%82%B4.jpg'),(6,'치즈돈까스','392495073','https://youngcheline.s3.ap-northeast-2.amazonaws.com/%EC%B9%98%EC%A6%88%EB%8F%88%EA%B9%8C%EC%8A%A4.png'),(7,'돈까스','392495073','https://youngcheline.s3.ap-northeast-2.amazonaws.com/%EB%8F%88%EA%B9%8C%EC%8A%A4.jpg'),(8,'차돌된장찌개','10306127','https://youngcheline.s3.ap-northeast-2.amazonaws.com/%EC%B0%A8%EB%8F%8C%EB%90%9C%EC%9E%A5%EC%B0%8C%EA%B0%9C.jpg'),(9,'김치말이냉국수','434788818','https://youngcheline.s3.ap-northeast-2.amazonaws.com/%EA%B9%80%EC%B9%98%EB%A7%90%EC%9D%B4%EB%83%89%EA%B5%AD%EC%88%98.jpg'),(10,'몽짬뽕','20638851','https://youngcheline.s3.ap-northeast-2.amazonaws.com/%EB%AA%BD%EC%A7%AC%EB%BD%95.jpg'),(11,'육회','1258680088','https://youngcheline.s3.ap-northeast-2.amazonaws.com/%EC%9C%A1%ED%9A%8C.png'),(12,'손시스시A','27407049','https://youngcheline.s3.ap-northeast-2.amazonaws.com/%EC%86%90%EC%8B%9C%EC%8A%A4%EC%8B%9CA.png'),(13,'항정살덮밥','27407036','https://youngcheline.s3.ap-northeast-2.amazonaws.com/%ED%95%AD%EC%A0%95%EC%82%B4.png'),(14,'상하이크림파스타','27407036','https://youngcheline.s3.ap-northeast-2.amazonaws.com/%EC%83%81%ED%95%98%EC%9D%B4%ED%81%AC%EB%A6%BC%ED%8C%8C%EC%8A%A4%ED%83%80.png'),(15,'영남동','444340519','https://youngcheline.s3.ap-northeast-2.amazonaws.com/%EC%98%81%EB%82%A8%EB%8F%99.png'),(16,'뒷고기','14541884','https://youngcheline.s3.ap-northeast-2.amazonaws.com/%EA%B9%80%ED%95%B4%EB%92%B7%EA%B3%A0%EA%B8%B0.png'),(17,'볶음밥','1566612864','https://youngcheline.s3.ap-northeast-2.amazonaws.com/%EB%B3%B6%EC%9D%8C%EB%B0%A5.png'),(18,'누텔라 아이스크림','226916996','https://youngcheline.s3.ap-northeast-2.amazonaws.com/%EB%88%84%ED%85%94%EB%9D%BC+%EC%95%84%EC%9D%B4%EC%8A%A4%ED%81%AC%EB%A6%BC.png'),(19,'마라전골','143343585','https://youngcheline.s3.ap-northeast-2.amazonaws.com/%EB%A7%88%EB%9D%BC%EC%A0%84%EA%B3%A8.png'),(20,'칼국수','880781940','https://youngcheline.s3.ap-northeast-2.amazonaws.com/%EC%B9%BC%EA%B5%AD%EC%88%98.png'),(21,'매콤크림우동','983114429','https://youngcheline.s3.ap-northeast-2.amazonaws.com/%EB%A7%A4%EC%BD%A4%ED%81%AC%EB%A6%BC%EC%9A%B0%EB%8F%99.png'),(22,'제육볶음','11300334','https://youngcheline.s3.ap-northeast-2.amazonaws.com/%EC%A0%9C%EC%9C%A1%EB%B3%B6%EC%9D%8C.png'),(23,'샐러드파스타','746623517','https://youngcheline.s3.ap-northeast-2.amazonaws.com/%EC%83%90%EB%9F%AC%EB%93%9C%ED%8C%8C%EC%8A%A4%ED%83%80.png'),(24,'돈돈까스','2020305821','https://youngcheline.s3.ap-northeast-2.amazonaws.com/%EB%8F%88%EB%8F%88%EA%B9%8C%EC%8A%A4.png'),(25,'등심돈까스','2020305821','https://youngcheline.s3.ap-northeast-2.amazonaws.com/%EB%93%B1%EC%8B%AC%EB%8F%88%EA%B9%8C%EC%8A%A4.png'),(26,'안심돈까스','2020305821','https://youngcheline.s3.ap-northeast-2.amazonaws.com/%EC%95%88%EC%8B%AC%EB%8F%88%EA%B9%8C%EC%8A%A4.png'),(27,'타이짬뽕','26353366','https://youngcheline.s3.ap-northeast-2.amazonaws.com/%ED%83%80%EC%9D%B4%EC%A7%AC%EB%BD%95.png'),(28,'목살플레이트','1956466361','https://youngcheline.s3.ap-northeast-2.amazonaws.com/%EB%AA%A9%EC%82%B4%ED%94%8C%EB%A0%88%EC%9D%B4%ED%8A%B8.png'),(29,'로제떡볶이','1032781993','https://youngcheline.s3.ap-northeast-2.amazonaws.com/%EB%A1%9C%EC%A0%9C%EB%96%A1%EB%B3%B6%EC%9D%B4.png'),(30,'갈비','1323716207','https://youngcheline.s3.ap-northeast-2.amazonaws.com/%EA%B0%88%EB%B9%84.png'),(31,'후라이드치킨','277055458','https://youngcheline.s3.ap-northeast-2.amazonaws.com/%ED%9B%84%EB%9D%BC%EC%9D%B4%EB%93%9C%EC%B9%98%ED%82%A8.png'),(32,'황금찜닭','777963780','https://youngcheline.s3.ap-northeast-2.amazonaws.com/%ED%99%A9%EA%B8%88%EC%B0%9C%EB%8B%AD.png'),(33,'가라아게','2084958402','https://youngcheline.s3.ap-northeast-2.amazonaws.com/%EA%B0%80%EB%9D%BC%EC%95%84%EA%B2%8C.png'),(34,'갈비동','86660948','https://youngcheline.s3.ap-northeast-2.amazonaws.com/%EA%B0%88%EB%B9%84%EB%8F%99.png'),(35,'치즈돈까스','2020305821','https://youngcheline.s3.ap-northeast-2.amazonaws.com/%EC%B9%98%EC%A6%88%EB%8F%88%EA%B9%8C%EC%8A%A4.png'),(36,'뿌링클','1817388398','https://youngcheline.s3.ap-northeast-2.amazonaws.com/1817388398_%EB%BF%8C%EB%A7%81%ED%81%B4_%E1%84%88%E1%85%AE%E1%84%85%E1%85%B5%E1%86%BC%E1%84%8F%E1%85%B3%E1%86%AF_410x271.png'),(37,'싸이버거','24371805','https://youngcheline.s3.ap-northeast-2.amazonaws.com/24371805_%EC%8B%B8%EC%9D%B4%EB%B2%84%EA%B1%B0_%E1%84%83%E1%85%A1%E1%84%8B%E1%85%AE%E1%86%AB%E1%84%85%E1%85%A9%E1%84%83%E1%85%B3.jpeg'),(38,'화이트 갈릭 버거','24371805','https://youngcheline.s3.ap-northeast-2.amazonaws.com/24371805_%ED%99%94%EC%9D%B4%ED%8A%B8%20%EA%B0%88%EB%A6%AD%20%EB%B2%84%EA%B1%B0_%E1%84%83%E1%85%A1%E1%84%8B%E1%85%AE%E1%86%AB%E1%84%85%E1%85%A9%E1%84%83%E1%85%B3%20%281%29.jpeg');
/*!40000 ALTER TABLE `menu` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2023-12-07 21:31:20
