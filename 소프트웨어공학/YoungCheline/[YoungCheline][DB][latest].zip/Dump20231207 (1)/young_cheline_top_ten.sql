-- MySQL dump 10.13  Distrib 8.0.33, for macos13 (arm64)
--
-- Host: 0.0.0.0    Database: young_cheline
-- ------------------------------------------------------
-- Server version	8.0.33

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `top_ten`
--

DROP TABLE IF EXISTS `top_ten`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `top_ten` (
  `menu_id` int DEFAULT NULL,
  `cleaning` varchar(255) DEFAULT NULL,
  `couple` varchar(255) DEFAULT NULL,
  `drink` varchar(255) DEFAULT NULL,
  `family` varchar(255) DEFAULT NULL,
  `friend` varchar(255) DEFAULT NULL,
  `menu_name` varchar(255) DEFAULT NULL,
  `plating` varchar(255) DEFAULT NULL,
  `price` varchar(255) DEFAULT NULL,
  `ranking` varchar(255) NOT NULL,
  `restaurant_id` varchar(255) DEFAULT NULL,
  `service` varchar(255) DEFAULT NULL,
  `solo` varchar(255) DEFAULT NULL,
  `flavor` varchar(255) DEFAULT NULL,
  `url` varchar(255) DEFAULT NULL,
  `user_name` varchar(255) NOT NULL,
  PRIMARY KEY (`ranking`,`user_name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `top_ten`
--

LOCK TABLES `top_ten` WRITE;
/*!40000 ALTER TABLE `top_ten` DISABLE KEYS */;
INSERT INTO `top_ten` VALUES (3,'1','0','3',NULL,NULL,'가라아게',NULL,NULL,'1','1','1',NULL,'1','https://youngcheline.s3.ap-northeast-2.amazonaws.com/%EA%B0%80%EB%9D%BC%EC%95%84%EA%B2%8C.png','ehddbs4521'),(8,'0',NULL,NULL,'1',NULL,'차돌된장찌개',NULL,NULL,'3','10306127',NULL,'2','2','https://youngcheline.s3.ap-northeast-2.amazonaws.com/%EC%B0%A8%EB%8F%8C%EB%90%9C%EC%9E%A5%EC%B0%8C%EA%B0%9C.jpg','ehddbs4521'),(22,NULL,NULL,NULL,NULL,'4','제육볶음',NULL,'3','4','11300334',NULL,NULL,'1','https://youngcheline.s3.ap-northeast-2.amazonaws.com/%EC%A0%9C%EC%9C%A1%EB%B3%B6%EC%9D%8C.png','ehddbs4521'),(5,'2',NULL,NULL,NULL,'4','삼겹살','1','3','6','287757696','2',NULL,'3','https://youngcheline.s3.ap-northeast-2.amazonaws.com/%EC%82%BC%EA%B2%B9%EC%82%B4.jpg','ehddbs4521');
/*!40000 ALTER TABLE `top_ten` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2023-12-07 21:31:20
