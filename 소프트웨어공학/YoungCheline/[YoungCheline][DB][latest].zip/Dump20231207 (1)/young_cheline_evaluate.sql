-- MySQL dump 10.13  Distrib 8.0.33, for macos13 (arm64)
--
-- Host: 0.0.0.0    Database: young_cheline
-- ------------------------------------------------------
-- Server version	8.0.33

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `evaluate`
--

DROP TABLE IF EXISTS `evaluate`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `evaluate` (
  `menu_id` int NOT NULL,
  `time` datetime(6) NOT NULL,
  `user_name` varchar(255) NOT NULL,
  `cleaning` varchar(255) DEFAULT NULL,
  `couple` varchar(255) DEFAULT NULL,
  `drink` varchar(255) DEFAULT NULL,
  `family` varchar(255) DEFAULT NULL,
  `friend` varchar(255) DEFAULT NULL,
  `plating` varchar(255) DEFAULT NULL,
  `price` varchar(255) DEFAULT NULL,
  `restaurant_id` varchar(255) DEFAULT NULL,
  `service` varchar(255) DEFAULT NULL,
  `solo` varchar(255) DEFAULT NULL,
  `flavor` varchar(255) DEFAULT NULL,
  `url` varchar(255) DEFAULT NULL,
  `id` int DEFAULT NULL,
  PRIMARY KEY (`menu_id`,`time`,`user_name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `evaluate`
--

LOCK TABLES `evaluate` WRITE;
/*!40000 ALTER TABLE `evaluate` DISABLE KEYS */;
INSERT INTO `evaluate` VALUES (3,'2023-12-07 00:00:00.000000','ehddbs4521','2',NULL,NULL,NULL,NULL,'1',NULL,'714569417','2',NULL,'3','https://youngcheline.s3.ap-northeast-2.amazonaws.com/%EA%BF%80%EA%B0%88%EB%B9%84.jpg',13),(4,'2023-12-07 00:00:00.000000','ehddbs4521',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'11385265','1',NULL,'2','https://youngcheline.s3.ap-northeast-2.amazonaws.com/%EB%8F%BC%EC%A7%80%EA%B5%AD%EB%B0%A5.jpg',4),(8,'2023-12-07 00:00:00.000000','ehddbs4521',NULL,NULL,NULL,NULL,'4','2',NULL,'10306127','1','2','3','https://youngcheline.s3.ap-northeast-2.amazonaws.com/%EC%B0%A8%EB%8F%8C%EB%90%9C%EC%9E%A5%EC%B0%8C%EA%B0%9C.jpg',2),(9,'2023-12-07 00:00:00.000000','ehddbs4521',NULL,'0','3',NULL,NULL,NULL,'4','434788818',NULL,'2','4','https://youngcheline.s3.ap-northeast-2.amazonaws.com/%EA%B9%80%EC%B9%98%EB%A7%90%EC%9D%B4%EB%83%89%EA%B5%AD%EC%88%98.jpg',15),(12,'2023-12-07 00:00:00.000000','ehddbs4521','1','0',NULL,'1',NULL,'2','2','27407049','1',NULL,'1','https://youngcheline.s3.ap-northeast-2.amazonaws.com/%EC%86%90%EC%8B%9C%EC%8A%A4%EC%8B%9CA.png',3),(18,'2023-12-07 00:00:00.000000','ehddbs4521',NULL,'0',NULL,'1',NULL,'2','2','226916996',NULL,NULL,'3','https://youngcheline.s3.ap-northeast-2.amazonaws.com/%EB%88%84%ED%85%94%EB%9D%BC+%EC%95%84%EC%9D%B4%EC%8A%A4%ED%81%AC%EB%A6%BC.png',14),(24,'2023-12-07 00:00:00.000000','ehddbs4521','1',NULL,NULL,NULL,NULL,NULL,NULL,'2020305821','3',NULL,'3','https://youngcheline.s3.ap-northeast-2.amazonaws.com/%EB%8F%88%EB%8F%88%EA%B9%8C%EC%8A%A4.png',16),(25,'2023-12-07 00:00:00.000000','ehddbs4521','1',NULL,NULL,NULL,NULL,'2','1','2020305821','1','2','2','https://youngcheline.s3.ap-northeast-2.amazonaws.com/%EB%93%B1%EC%8B%AC%EB%8F%88%EA%B9%8C%EC%8A%A4.png',12),(27,'2023-12-07 00:00:00.000000','ehddbs4521',NULL,'0',NULL,'1',NULL,NULL,'1','26353366',NULL,NULL,'1','https://youngcheline.s3.ap-northeast-2.amazonaws.com/%ED%83%80%EC%9D%B4%EC%A7%AC%EB%BD%95.png',6),(28,'2023-12-07 00:00:00.000000','ehddbs4521',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1956466361',NULL,NULL,'4','https://youngcheline.s3.ap-northeast-2.amazonaws.com/%EB%AA%A9%EC%82%B4%ED%94%8C%EB%A0%88%EC%9D%B4%ED%8A%B8.png',10),(31,'2023-12-07 00:00:00.000000','ehddbs4521','2',NULL,NULL,NULL,NULL,NULL,'2','277055458',NULL,'2','1','https://youngcheline.s3.ap-northeast-2.amazonaws.com/%ED%9B%84%EB%9D%BC%EC%9D%B4%EB%93%9C%EC%B9%98%ED%82%A8.png',17),(38,'2023-12-07 12:30:15.973903','ehddbs4521','1','0',NULL,NULL,NULL,'0','0','24371805',NULL,'2','2','https://youngcheline.s3.ap-northeast-2.amazonaws.com/38_38-thumbnail',18);
/*!40000 ALTER TABLE `evaluate` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2023-12-07 21:31:20
