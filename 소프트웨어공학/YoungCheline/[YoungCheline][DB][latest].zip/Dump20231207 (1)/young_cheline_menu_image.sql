-- MySQL dump 10.13  Distrib 8.0.33, for macos13 (arm64)
--
-- Host: 0.0.0.0    Database: young_cheline
-- ------------------------------------------------------
-- Server version	8.0.33

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `menu_image`
--

DROP TABLE IF EXISTS `menu_image`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `menu_image` (
  `menu_id` int NOT NULL,
  `time` datetime(6) NOT NULL,
  `url` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`menu_id`,`time`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `menu_image`
--

LOCK TABLES `menu_image` WRITE;
/*!40000 ALTER TABLE `menu_image` DISABLE KEYS */;
INSERT INTO `menu_image` VALUES (1,'2023-11-21 21:32:18.158083','https://youngcheline.s3.ap-northeast-2.amazonaws.com/2020305821_%EC%B9%98%EC%A6%88%EB%8F%88%EA%B9%8C%EC%8A%A4_%E1%84%83%E1%85%A1%E1%84%8B%E1%85%AE%E1%86%AB%E1%84%85%E1%85%A9%E1%84%83%E1%85%B3.jpeg'),(1,'2023-11-21 21:32:56.639873','https://youngcheline.s3.ap-northeast-2.amazonaws.com/2020305821_%EC%B9%98%EC%A6%88%EB%8F%88%EA%B9%8C%EC%8A%A4_%E1%84%83%E1%85%A1%E1%84%8B%E1%85%AE%E1%86%AB%E1%84%85%E1%85%A9%E1%84%83%E1%85%B3.jpeg'),(8,'2023-12-04 20:48:23.235938','https://youngcheline.s3.ap-northeast-2.amazonaws.com/2020305821_%EC%B9%98%EC%A6%88%EB%8F%88%EA%B9%8C%EC%8A%A4_%E1%84%83%E1%85%A1%E1%84%8B%E1%85%AE%E1%86%AB%E1%84%85%E1%85%A9%E1%84%83%E1%85%B3.jpeg'),(8,'2023-12-04 20:50:39.325735','https://youngcheline.s3.ap-northeast-2.amazonaws.com/2020305821_%EC%B9%98%EC%A6%88%EB%8F%88%EA%B9%8C%EC%8A%A4_%E1%84%83%E1%85%A1%E1%84%8B%E1%85%AE%E1%86%AB%E1%84%85%E1%85%A9%E1%84%83%E1%85%B3.jpeg'),(8,'2023-12-04 20:59:57.638092','https://youngcheline.s3.ap-northeast-2.amazonaws.com/2020305821_%EC%B9%98%EC%A6%88%EB%8F%88%EA%B9%8C%EC%8A%A4_%E1%84%83%E1%85%A1%E1%84%8B%E1%85%AE%E1%86%AB%E1%84%85%E1%85%A9%E1%84%83%E1%85%B3.jpeg'),(8,'2023-12-04 21:00:32.795713','https://youngcheline.s3.ap-northeast-2.amazonaws.com/2020305821_%EC%B9%98%EC%A6%88%EB%8F%88%EA%B9%8C%EC%8A%A4_%E1%84%83%E1%85%A1%E1%84%8B%E1%85%AE%E1%86%AB%E1%84%85%E1%85%A9%E1%84%83%E1%85%B3.jpeg'),(8,'2023-12-06 11:58:08.002693','https://youngcheline.s3.ap-northeast-2.amazonaws.com/8_8-thumbnail'),(8,'2023-12-06 12:25:04.214293','https://youngcheline.s3.ap-northeast-2.amazonaws.com/8_8-thumbnail'),(8,'2023-12-06 15:47:21.257930','https://youngcheline.s3.ap-northeast-2.amazonaws.com/8_8-thumbnail'),(25,'2023-12-04 21:02:29.689326','https://youngcheline.s3.ap-northeast-2.amazonaws.com/2020305821_%EC%B9%98%EC%A6%88%EB%8F%88%EA%B9%8C%EC%8A%A4_%E1%84%83%E1%85%A1%E1%84%8B%E1%85%AE%E1%86%AB%E1%84%85%E1%85%A9%E1%84%83%E1%85%B3.jpeg'),(26,'2023-12-05 18:56:37.413689','https://youngcheline.s3.ap-northeast-2.amazonaws.com/2020305821_%EC%B9%98%EC%A6%88%EB%8F%88%EA%B9%8C%EC%8A%A4_%E1%84%83%E1%85%A1%E1%84%8B%E1%85%AE%E1%86%AB%E1%84%85%E1%85%A9%E1%84%83%E1%85%B3.jpeg'),(26,'2023-12-05 18:57:05.611814','https://youngcheline.s3.ap-northeast-2.amazonaws.com/2020305821_%EC%B9%98%EC%A6%88%EB%8F%88%EA%B9%8C%EC%8A%A4_%E1%84%83%E1%85%A1%E1%84%8B%E1%85%AE%E1%86%AB%E1%84%85%E1%85%A9%E1%84%83%E1%85%B3.jpeg'),(35,'2023-12-05 21:29:21.759361','https://youngcheline.s3.ap-northeast-2.amazonaws.com/2020305821_%EC%B9%98%EC%A6%88%EB%8F%88%EA%B9%8C%EC%8A%A4_%E1%84%83%E1%85%A1%E1%84%8B%E1%85%AE%E1%86%AB%E1%84%85%E1%85%A9%E1%84%83%E1%85%B3.jpeg'),(36,'2023-12-07 12:06:00.449788','https://youngcheline.s3.ap-northeast-2.amazonaws.com/1817388398_%EB%BF%8C%EB%A7%81%ED%81%B4_%E1%84%88%E1%85%AE%E1%84%85%E1%85%B5%E1%86%BC%E1%84%8F%E1%85%B3%E1%86%AF_410x271.png'),(36,'2023-12-07 12:06:18.957487','https://youngcheline.s3.ap-northeast-2.amazonaws.com/36_36-thumbnail'),(37,'2023-12-07 12:11:01.815635','https://youngcheline.s3.ap-northeast-2.amazonaws.com/24371805_%EC%8B%B8%EC%9D%B4%EB%B2%84%EA%B1%B0_%E1%84%83%E1%85%A1%E1%84%8B%E1%85%AE%E1%86%AB%E1%84%85%E1%85%A9%E1%84%83%E1%85%B3.jpeg'),(37,'2023-12-07 12:11:24.289833','https://youngcheline.s3.ap-northeast-2.amazonaws.com/37_37-thumbnail'),(38,'2023-12-07 12:29:50.552008','https://youngcheline.s3.ap-northeast-2.amazonaws.com/24371805_%ED%99%94%EC%9D%B4%ED%8A%B8%20%EA%B0%88%EB%A6%AD%20%EB%B2%84%EA%B1%B0_%E1%84%83%E1%85%A1%E1%84%8B%E1%85%AE%E1%86%AB%E1%84%85%E1%85%A9%E1%84%83%E1%85%B3%20%281%29.jpeg'),(38,'2023-12-07 12:30:15.973903','https://youngcheline.s3.ap-northeast-2.amazonaws.com/38_38-thumbnail');
/*!40000 ALTER TABLE `menu_image` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2023-12-07 21:31:20
