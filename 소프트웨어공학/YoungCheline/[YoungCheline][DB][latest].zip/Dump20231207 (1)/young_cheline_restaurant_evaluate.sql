-- MySQL dump 10.13  Distrib 8.0.33, for macos13 (arm64)
--
-- Host: 0.0.0.0    Database: young_cheline
-- ------------------------------------------------------
-- Server version	8.0.33

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `restaurant_evaluate`
--

DROP TABLE IF EXISTS `restaurant_evaluate`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `restaurant_evaluate` (
  `menu_id` int DEFAULT NULL,
  `cleaning` varchar(255) DEFAULT NULL,
  `menu_name` varchar(255) DEFAULT NULL,
  `plating` varchar(255) DEFAULT NULL,
  `price` varchar(255) DEFAULT NULL,
  `restaurant_id` varchar(255) DEFAULT NULL,
  `service` varchar(255) DEFAULT NULL,
  `flavor` varchar(255) DEFAULT NULL,
  `id` int NOT NULL AUTO_INCREMENT,
  `couple` varchar(255) DEFAULT NULL,
  `drink` varchar(255) DEFAULT NULL,
  `family` varchar(255) DEFAULT NULL,
  `friend` varchar(255) DEFAULT NULL,
  `solo` varchar(255) DEFAULT NULL,
  `url` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=36 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `restaurant_evaluate`
--

LOCK TABLES `restaurant_evaluate` WRITE;
/*!40000 ALTER TABLE `restaurant_evaluate` DISABLE KEYS */;
INSERT INTO `restaurant_evaluate` VALUES (1,'2','대창덮밥','2','2','1883770159','2','2',1,NULL,NULL,NULL,NULL,NULL,'https://youngcheline.s3.ap-northeast-2.amazonaws.com/%EB%8C%80%EC%B0%BD%EB%8D%AE%EB%B0%A5.jpg'),(2,'2','뚝배기','2','2','15752650','2','2',2,NULL,NULL,NULL,NULL,NULL,'https://youngcheline.s3.ap-northeast-2.amazonaws.com/%EB%9A%9D%EB%B0%B0%EA%B8%B0.jpg'),(3,'2','꿀갈비비빔밥','2','2','714569417','2','2',3,NULL,NULL,NULL,NULL,NULL,'https://youngcheline.s3.ap-northeast-2.amazonaws.com/%EA%BF%80%EA%B0%88%EB%B9%84.jpg'),(4,'2','돼지국밥','2','2','11385265','2','2',4,NULL,NULL,NULL,NULL,NULL,'https://youngcheline.s3.ap-northeast-2.amazonaws.com/%EB%8F%BC%EC%A7%80%EA%B5%AD%EB%B0%A5.jpg'),(5,'2','삼겹살','2','2','287757696','2','2',5,NULL,NULL,NULL,NULL,NULL,'https://youngcheline.s3.ap-northeast-2.amazonaws.com/%EC%82%BC%EA%B2%B9%EC%82%B4.jpg'),(6,'2','치즈돈까스','2','2','392495073','2','2',6,NULL,NULL,NULL,NULL,NULL,'https://youngcheline.s3.ap-northeast-2.amazonaws.com/%EC%B9%98%EC%A6%88%EB%8F%88%EA%B9%8C%EC%8A%A4.png'),(7,'2','돈까스','2','2','392495073','2','2',7,NULL,NULL,NULL,NULL,NULL,'https://youngcheline.s3.ap-northeast-2.amazonaws.com/%EB%8F%88%EA%B9%8C%EC%8A%A4.jpg'),(8,'2','차돌된장찌개','2','2','10306127','2','2',8,NULL,NULL,NULL,NULL,NULL,'https://youngcheline.s3.ap-northeast-2.amazonaws.com/%EC%B0%A8%EB%8F%8C%EB%90%9C%EC%9E%A5%EC%B0%8C%EA%B0%9C.jpg'),(9,'2','김치말이냉국수','2','2','434788818','2','2',9,NULL,NULL,NULL,NULL,NULL,'https://youngcheline.s3.ap-northeast-2.amazonaws.com/%EA%B9%80%EC%B9%98%EB%A7%90%EC%9D%B4%EB%83%89%EA%B5%AD%EC%88%98.jpg'),(10,'2','몽짬뽕','2','2','20638851','2','2',10,NULL,NULL,NULL,NULL,NULL,'https://youngcheline.s3.ap-northeast-2.amazonaws.com/%EB%AA%BD%EC%A7%AC%EB%BD%95.jpg'),(11,'2','육회','2','2','1258680088','2','2',11,NULL,NULL,NULL,NULL,NULL,'https://youngcheline.s3.ap-northeast-2.amazonaws.com/%EC%9C%A1%ED%9A%8C.png'),(12,'2','손시스시A','2','2','27407049','2','2',12,NULL,NULL,NULL,NULL,NULL,'https://youngcheline.s3.ap-northeast-2.amazonaws.com/%EC%86%90%EC%8B%9C%EC%8A%A4%EC%8B%9CA.png'),(13,'2','항정살덮밥','2','2','27407036','2','2',13,NULL,NULL,NULL,NULL,NULL,'https://youngcheline.s3.ap-northeast-2.amazonaws.com/%ED%95%AD%EC%A0%95%EC%82%B4.png'),(14,'2','상하이크림파스타','2','2','27407036','2','2',14,NULL,NULL,NULL,NULL,NULL,'https://youngcheline.s3.ap-northeast-2.amazonaws.com/%EC%83%81%ED%95%98%EC%9D%B4%ED%81%AC%EB%A6%BC%ED%8C%8C%EC%8A%A4%ED%83%80.png'),(15,'2','영남동','2','2','444340519','2','2',15,NULL,NULL,NULL,NULL,NULL,'https://youngcheline.s3.ap-northeast-2.amazonaws.com/%EC%98%81%EB%82%A8%EB%8F%99.png'),(16,'2','뒷고기','2','2','14541884','2','2',16,NULL,NULL,NULL,NULL,NULL,'https://youngcheline.s3.ap-northeast-2.amazonaws.com/%EA%B9%80%ED%95%B4%EB%92%B7%EA%B3%A0%EA%B8%B0.png'),(17,'2','볶음밥','2','2','1566612864','2','2',17,NULL,NULL,NULL,NULL,NULL,'https://youngcheline.s3.ap-northeast-2.amazonaws.com/%EB%B3%B6%EC%9D%8C%EB%B0%A5.png'),(18,'2','누텔라 아이스크림','2','2','226916996','2','2',18,NULL,NULL,NULL,NULL,NULL,'https://youngcheline.s3.ap-northeast-2.amazonaws.com/%EB%88%84%ED%85%94%EB%9D%BC+%EC%95%84%EC%9D%B4%EC%8A%A4%ED%81%AC%EB%A6%BC.png'),(19,'2','마라전골','2','2','143343585','2','2',19,NULL,NULL,NULL,NULL,NULL,'https://youngcheline.s3.ap-northeast-2.amazonaws.com/%EB%A7%88%EB%9D%BC%EC%A0%84%EA%B3%A8.png'),(20,'2','칼국수','2','2','880781940','2','2',20,NULL,NULL,NULL,NULL,NULL,'https://youngcheline.s3.ap-northeast-2.amazonaws.com/%EC%B9%BC%EA%B5%AD%EC%88%98.png'),(21,'1','매콤크림우동','1','1','983114429','1','2',21,NULL,NULL,NULL,NULL,NULL,'https://youngcheline.s3.ap-northeast-2.amazonaws.com/%EB%A7%A4%EC%BD%A4%ED%81%AC%EB%A6%BC%EC%9A%B0%EB%8F%99.png'),(22,'2','제육볶음','2','2','11300334','2','2',22,NULL,NULL,NULL,NULL,NULL,'https://youngcheline.s3.ap-northeast-2.amazonaws.com/%EC%A0%9C%EC%9C%A1%EB%B3%B6%EC%9D%8C.png'),(23,'2','샐러드파스타','2','2','746623517','2','2',23,NULL,NULL,NULL,NULL,NULL,'https://youngcheline.s3.ap-northeast-2.amazonaws.com/%EC%83%90%EB%9F%AC%EB%93%9C%ED%8C%8C%EC%8A%A4%ED%83%80.png'),(24,'2','돈돈까스','2','2','2020305821','2','2',24,NULL,NULL,NULL,NULL,NULL,'https://youngcheline.s3.ap-northeast-2.amazonaws.com/%EB%8F%88%EB%8F%88%EA%B9%8C%EC%8A%A4.png'),(25,'2','등심돈까스','2','2','2020305821','2','2',25,NULL,NULL,NULL,NULL,NULL,'https://youngcheline.s3.ap-northeast-2.amazonaws.com/%EB%93%B1%EC%8B%AC%EB%8F%88%EA%B9%8C%EC%8A%A4.png'),(26,'2','안심돈까스','2','2','2020305821','2','2',26,NULL,NULL,NULL,NULL,NULL,'https://youngcheline.s3.ap-northeast-2.amazonaws.com/%EC%95%88%EC%8B%AC%EB%8F%88%EA%B9%8C%EC%8A%A4.png'),(27,'2','타이짬뽕','2','2','26353366','2','2',27,NULL,NULL,NULL,NULL,NULL,'https://youngcheline.s3.ap-northeast-2.amazonaws.com/%ED%83%80%EC%9D%B4%EC%A7%AC%EB%BD%95.png'),(28,'2','목살플레이트','2','2','1956466361','2','2',28,NULL,NULL,NULL,NULL,NULL,'https://youngcheline.s3.ap-northeast-2.amazonaws.com/%EB%AA%A9%EC%82%B4%ED%94%8C%EB%A0%88%EC%9D%B4%ED%8A%B8.png'),(29,'2','로제떡볶이','2','2','1032781993','2','2',29,NULL,NULL,NULL,NULL,NULL,'https://youngcheline.s3.ap-northeast-2.amazonaws.com/%EB%A1%9C%EC%A0%9C%EB%96%A1%EB%B3%B6%EC%9D%B4.png'),(30,'2','갈비','2','2','1323716207','2','2',30,NULL,NULL,NULL,NULL,NULL,'https://youngcheline.s3.ap-northeast-2.amazonaws.com/%EA%B0%88%EB%B9%84.png'),(31,'2','후라이드치킨','2','2','277055458','2','2',31,NULL,NULL,NULL,NULL,NULL,'https://youngcheline.s3.ap-northeast-2.amazonaws.com/%ED%9B%84%EB%9D%BC%EC%9D%B4%EB%93%9C%EC%B9%98%ED%82%A8.png'),(32,'2','황금찜닭','2','2','777963780','2','2',32,NULL,NULL,NULL,NULL,NULL,'https://youngcheline.s3.ap-northeast-2.amazonaws.com/%ED%99%A9%EA%B8%88%EC%B0%9C%EB%8B%AD.png'),(33,'2','가라아게','2','2','2084958402','2','2',33,NULL,NULL,NULL,NULL,NULL,'https://youngcheline.s3.ap-northeast-2.amazonaws.com/%EA%B0%80%EB%9D%BC%EC%95%84%EA%B2%8C.png'),(34,'2','갈비동','2','2','86660948','2','2',34,NULL,NULL,NULL,NULL,NULL,'https://youngcheline.s3.ap-northeast-2.amazonaws.com/%EA%B0%88%EB%B9%84%EB%8F%99.png'),(35,'2','치즈돈까스','2','2','2020305821','2','2',35,NULL,NULL,NULL,NULL,NULL,'https://youngcheline.s3.ap-northeast-2.amazonaws.com/%EC%B9%98%EC%A6%88%EB%8F%88%EA%B9%8C%EC%8A%A4.png');
/*!40000 ALTER TABLE `restaurant_evaluate` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2023-12-07 21:31:20
