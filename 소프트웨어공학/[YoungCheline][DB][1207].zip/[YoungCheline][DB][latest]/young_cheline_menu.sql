-- MySQL dump 10.13  Distrib 8.0.34, for Win64 (x86_64)
--
-- Host: 127.0.0.1    Database: young_cheline
-- ------------------------------------------------------
-- Server version	8.0.35

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `menu`
--

DROP TABLE IF EXISTS `menu`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `menu` (
  `menu_id` int NOT NULL AUTO_INCREMENT,
  `menu_name` varchar(255) DEFAULT NULL,
  `restaurant_id` varchar(255) DEFAULT NULL,
  `url` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`menu_id`)
) ENGINE=InnoDB AUTO_INCREMENT=36 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `menu`
--

LOCK TABLES `menu` WRITE;
/*!40000 ALTER TABLE `menu` DISABLE KEYS */;
INSERT INTO `menu` VALUES (1,'대창덮밥','1883770159','https://youngcheline.s3.ap-northeast-2.amazonaws.com/2020305821_%EC%B9%98%EC%A6%88%EB%8F%88%EA%B9%8C%EC%8A%A4_%E1%84%83%E1%85%A1%E1%84%8B%E1%85%AE%E1%86%AB%E1%84%85%E1%85%A9%E1%84%83%E1%85%B3.jpeg'),(2,'뚝배기','15752650','https://youngcheline.s3.ap-northeast-2.amazonaws.com/2020305821_%EC%B9%98%EC%A6%88%EB%8F%88%EA%B9%8C%EC%8A%A4_%E1%84%83%E1%85%A1%E1%84%8B%E1%85%AE%E1%86%AB%E1%84%85%E1%85%A9%E1%84%83%E1%85%B3.jpeg'),(3,'꿀갈비비빔밥','714569417','https://youngcheline.s3.ap-northeast-2.amazonaws.com/2020305821_%EC%B9%98%EC%A6%88%EB%8F%88%EA%B9%8C%EC%8A%A4_%E1%84%83%E1%85%A1%E1%84%8B%E1%85%AE%E1%86%AB%E1%84%85%E1%85%A9%E1%84%83%E1%85%B3.jpeg'),(4,'돼지국밥','11385265','https://youngcheline.s3.ap-northeast-2.amazonaws.com/2020305821_%EC%B9%98%EC%A6%88%EB%8F%88%EA%B9%8C%EC%8A%A4_%E1%84%83%E1%85%A1%E1%84%8B%E1%85%AE%E1%86%AB%E1%84%85%E1%85%A9%E1%84%83%E1%85%B3.jpeg'),(5,'삼겹살','287757696','https://youngcheline.s3.ap-northeast-2.amazonaws.com/2020305821_%EC%B9%98%EC%A6%88%EB%8F%88%EA%B9%8C%EC%8A%A4_%E1%84%83%E1%85%A1%E1%84%8B%E1%85%AE%E1%86%AB%E1%84%85%E1%85%A9%E1%84%83%E1%85%B3.jpeg'),(6,'치즈돈까스','392495073','https://youngcheline.s3.ap-northeast-2.amazonaws.com/2020305821_%EC%B9%98%EC%A6%88%EB%8F%88%EA%B9%8C%EC%8A%A4_%E1%84%83%E1%85%A1%E1%84%8B%E1%85%AE%E1%86%AB%E1%84%85%E1%85%A9%E1%84%83%E1%85%B3.jpeg'),(7,'돈까스','392495073','https://youngcheline.s3.ap-northeast-2.amazonaws.com/2020305821_%EC%B9%98%EC%A6%88%EB%8F%88%EA%B9%8C%EC%8A%A4_%E1%84%83%E1%85%A1%E1%84%8B%E1%85%AE%E1%86%AB%E1%84%85%E1%85%A9%E1%84%83%E1%85%B3.jpeg'),(8,'차돌된장찌개','10306127','https://youngcheline.s3.ap-northeast-2.amazonaws.com/2020305821_%EC%B9%98%EC%A6%88%EB%8F%88%EA%B9%8C%EC%8A%A4_%E1%84%83%E1%85%A1%E1%84%8B%E1%85%AE%E1%86%AB%E1%84%85%E1%85%A9%E1%84%83%E1%85%B3.jpeg'),(9,'김치말이냉국수','434788818','https://youngcheline.s3.ap-northeast-2.amazonaws.com/2020305821_%EC%B9%98%EC%A6%88%EB%8F%88%EA%B9%8C%EC%8A%A4_%E1%84%83%E1%85%A1%E1%84%8B%E1%85%AE%E1%86%AB%E1%84%85%E1%85%A9%E1%84%83%E1%85%B3.jpeg'),(10,'몽짬뽕','20638851','https://youngcheline.s3.ap-northeast-2.amazonaws.com/2020305821_%EC%B9%98%EC%A6%88%EB%8F%88%EA%B9%8C%EC%8A%A4_%E1%84%83%E1%85%A1%E1%84%8B%E1%85%AE%E1%86%AB%E1%84%85%E1%85%A9%E1%84%83%E1%85%B3.jpeg'),(11,'육회','1258680088','https://youngcheline.s3.ap-northeast-2.amazonaws.com/2020305821_%EC%B9%98%EC%A6%88%EB%8F%88%EA%B9%8C%EC%8A%A4_%E1%84%83%E1%85%A1%E1%84%8B%E1%85%AE%E1%86%AB%E1%84%85%E1%85%A9%E1%84%83%E1%85%B3.jpeg'),(12,'손시스시A','27407049','https://youngcheline.s3.ap-northeast-2.amazonaws.com/2020305821_%EC%B9%98%EC%A6%88%EB%8F%88%EA%B9%8C%EC%8A%A4_%E1%84%83%E1%85%A1%E1%84%8B%E1%85%AE%E1%86%AB%E1%84%85%E1%85%A9%E1%84%83%E1%85%B3.jpeg'),(13,'항정살덮밥','27407036','https://youngcheline.s3.ap-northeast-2.amazonaws.com/2020305821_%EC%B9%98%EC%A6%88%EB%8F%88%EA%B9%8C%EC%8A%A4_%E1%84%83%E1%85%A1%E1%84%8B%E1%85%AE%E1%86%AB%E1%84%85%E1%85%A9%E1%84%83%E1%85%B3.jpeg'),(14,'상하이크림파스타','27407036','https://youngcheline.s3.ap-northeast-2.amazonaws.com/2020305821_%EC%B9%98%EC%A6%88%EB%8F%88%EA%B9%8C%EC%8A%A4_%E1%84%83%E1%85%A1%E1%84%8B%E1%85%AE%E1%86%AB%E1%84%85%E1%85%A9%E1%84%83%E1%85%B3.jpeg'),(15,'영남동','444340519','https://youngcheline.s3.ap-northeast-2.amazonaws.com/2020305821_%EC%B9%98%EC%A6%88%EB%8F%88%EA%B9%8C%EC%8A%A4_%E1%84%83%E1%85%A1%E1%84%8B%E1%85%AE%E1%86%AB%E1%84%85%E1%85%A9%E1%84%83%E1%85%B3.jpeg'),(16,'뒷고기','14541884','https://youngcheline.s3.ap-northeast-2.amazonaws.com/2020305821_%EC%B9%98%EC%A6%88%EB%8F%88%EA%B9%8C%EC%8A%A4_%E1%84%83%E1%85%A1%E1%84%8B%E1%85%AE%E1%86%AB%E1%84%85%E1%85%A9%E1%84%83%E1%85%B3.jpeg'),(17,'볶음밥','1566612864','https://youngcheline.s3.ap-northeast-2.amazonaws.com/2020305821_%EC%B9%98%EC%A6%88%EB%8F%88%EA%B9%8C%EC%8A%A4_%E1%84%83%E1%85%A1%E1%84%8B%E1%85%AE%E1%86%AB%E1%84%85%E1%85%A9%E1%84%83%E1%85%B3.jpeg'),(18,'누텔라 아이스크림','226916996','https://youngcheline.s3.ap-northeast-2.amazonaws.com/2020305821_%EC%B9%98%EC%A6%88%EB%8F%88%EA%B9%8C%EC%8A%A4_%E1%84%83%E1%85%A1%E1%84%8B%E1%85%AE%E1%86%AB%E1%84%85%E1%85%A9%E1%84%83%E1%85%B3.jpeg'),(19,'마라전골','143343585','https://youngcheline.s3.ap-northeast-2.amazonaws.com/2020305821_%EC%B9%98%EC%A6%88%EB%8F%88%EA%B9%8C%EC%8A%A4_%E1%84%83%E1%85%A1%E1%84%8B%E1%85%AE%E1%86%AB%E1%84%85%E1%85%A9%E1%84%83%E1%85%B3.jpeg'),(20,'칼국수','880781940','https://youngcheline.s3.ap-northeast-2.amazonaws.com/2020305821_%EC%B9%98%EC%A6%88%EB%8F%88%EA%B9%8C%EC%8A%A4_%E1%84%83%E1%85%A1%E1%84%8B%E1%85%AE%E1%86%AB%E1%84%85%E1%85%A9%E1%84%83%E1%85%B3.jpeg'),(21,'매콤크림우동','983114429','https://youngcheline.s3.ap-northeast-2.amazonaws.com/2020305821_%EC%B9%98%EC%A6%88%EB%8F%88%EA%B9%8C%EC%8A%A4_%E1%84%83%E1%85%A1%E1%84%8B%E1%85%AE%E1%86%AB%E1%84%85%E1%85%A9%E1%84%83%E1%85%B3.jpeg'),(22,'제육볶음','11300334','https://youngcheline.s3.ap-northeast-2.amazonaws.com/2020305821_%EC%B9%98%EC%A6%88%EB%8F%88%EA%B9%8C%EC%8A%A4_%E1%84%83%E1%85%A1%E1%84%8B%E1%85%AE%E1%86%AB%E1%84%85%E1%85%A9%E1%84%83%E1%85%B3.jpeg'),(23,'샐러드파스타','746623517','https://youngcheline.s3.ap-northeast-2.amazonaws.com/2020305821_%EC%B9%98%EC%A6%88%EB%8F%88%EA%B9%8C%EC%8A%A4_%E1%84%83%E1%85%A1%E1%84%8B%E1%85%AE%E1%86%AB%E1%84%85%E1%85%A9%E1%84%83%E1%85%B3.jpeg'),(24,'돈돈까스','2020305821','https://youngcheline.s3.ap-northeast-2.amazonaws.com/2020305821_%EC%B9%98%EC%A6%88%EB%8F%88%EA%B9%8C%EC%8A%A4_%E1%84%83%E1%85%A1%E1%84%8B%E1%85%AE%E1%86%AB%E1%84%85%E1%85%A9%E1%84%83%E1%85%B3.jpeg'),(25,'등심돈까스','2020305821','https://youngcheline.s3.ap-northeast-2.amazonaws.com/2020305821_%EC%B9%98%EC%A6%88%EB%8F%88%EA%B9%8C%EC%8A%A4_%E1%84%83%E1%85%A1%E1%84%8B%E1%85%AE%E1%86%AB%E1%84%85%E1%85%A9%E1%84%83%E1%85%B3.jpeg'),(26,'안심돈까스','2020305821','https://youngcheline.s3.ap-northeast-2.amazonaws.com/2020305821_%EC%B9%98%EC%A6%88%EB%8F%88%EA%B9%8C%EC%8A%A4_%E1%84%83%E1%85%A1%E1%84%8B%E1%85%AE%E1%86%AB%E1%84%85%E1%85%A9%E1%84%83%E1%85%B3.jpeg'),(27,'타이짬뽕','26353366','https://youngcheline.s3.ap-northeast-2.amazonaws.com/2020305821_%EC%B9%98%EC%A6%88%EB%8F%88%EA%B9%8C%EC%8A%A4_%E1%84%83%E1%85%A1%E1%84%8B%E1%85%AE%E1%86%AB%E1%84%85%E1%85%A9%E1%84%83%E1%85%B3.jpeg'),(28,'목살플레이트','1956466361','https://youngcheline.s3.ap-northeast-2.amazonaws.com/2020305821_%EC%B9%98%EC%A6%88%EB%8F%88%EA%B9%8C%EC%8A%A4_%E1%84%83%E1%85%A1%E1%84%8B%E1%85%AE%E1%86%AB%E1%84%85%E1%85%A9%E1%84%83%E1%85%B3.jpeg'),(29,'로제떡볶이','1032781993','https://youngcheline.s3.ap-northeast-2.amazonaws.com/2020305821_%EC%B9%98%EC%A6%88%EB%8F%88%EA%B9%8C%EC%8A%A4_%E1%84%83%E1%85%A1%E1%84%8B%E1%85%AE%E1%86%AB%E1%84%85%E1%85%A9%E1%84%83%E1%85%B3.jpeg'),(30,'갈비','1323716207','https://youngcheline.s3.ap-northeast-2.amazonaws.com/2020305821_%EC%B9%98%EC%A6%88%EB%8F%88%EA%B9%8C%EC%8A%A4_%E1%84%83%E1%85%A1%E1%84%8B%E1%85%AE%E1%86%AB%E1%84%85%E1%85%A9%E1%84%83%E1%85%B3.jpeg'),(31,'후라이드치킨','277055458','https://youngcheline.s3.ap-northeast-2.amazonaws.com/2020305821_%EC%B9%98%EC%A6%88%EB%8F%88%EA%B9%8C%EC%8A%A4_%E1%84%83%E1%85%A1%E1%84%8B%E1%85%AE%E1%86%AB%E1%84%85%E1%85%A9%E1%84%83%E1%85%B3.jpeg'),(32,'황금찜닭','777963780','https://youngcheline.s3.ap-northeast-2.amazonaws.com/2020305821_%EC%B9%98%EC%A6%88%EB%8F%88%EA%B9%8C%EC%8A%A4_%E1%84%83%E1%85%A1%E1%84%8B%E1%85%AE%E1%86%AB%E1%84%85%E1%85%A9%E1%84%83%E1%85%B3.jpeg'),(33,'가라아게','2084958402','https://youngcheline.s3.ap-northeast-2.amazonaws.com/2020305821_%EC%B9%98%EC%A6%88%EB%8F%88%EA%B9%8C%EC%8A%A4_%E1%84%83%E1%85%A1%E1%84%8B%E1%85%AE%E1%86%AB%E1%84%85%E1%85%A9%E1%84%83%E1%85%B3.jpeg'),(34,'갈비동','86660948','https://youngcheline.s3.ap-northeast-2.amazonaws.com/2020305821_%EC%B9%98%EC%A6%88%EB%8F%88%EA%B9%8C%EC%8A%A4_%E1%84%83%E1%85%A1%E1%84%8B%E1%85%AE%E1%86%AB%E1%84%85%E1%85%A9%E1%84%83%E1%85%B3.jpeg'),(35,'치즈돈까스','2020305821','https://youngcheline.s3.ap-northeast-2.amazonaws.com/2020305821_%EC%B9%98%EC%A6%88%EB%8F%88%EA%B9%8C%EC%8A%A4_%E1%84%83%E1%85%A1%E1%84%8B%E1%85%AE%E1%86%AB%E1%84%85%E1%85%A9%E1%84%83%E1%85%B3.jpeg');
/*!40000 ALTER TABLE `menu` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2023-12-07 18:23:38
