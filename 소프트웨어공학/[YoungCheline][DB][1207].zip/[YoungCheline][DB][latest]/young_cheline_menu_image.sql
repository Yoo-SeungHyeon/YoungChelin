-- MySQL dump 10.13  Distrib 8.0.34, for Win64 (x86_64)
--
-- Host: 127.0.0.1    Database: young_cheline
-- ------------------------------------------------------
-- Server version	8.0.35

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `menu_image`
--

DROP TABLE IF EXISTS `menu_image`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `menu_image` (
  `menu_id` int NOT NULL,
  `time` varchar(255) NOT NULL,
  `url` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`menu_id`,`time`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `menu_image`
--

LOCK TABLES `menu_image` WRITE;
/*!40000 ALTER TABLE `menu_image` DISABLE KEYS */;
INSERT INTO `menu_image` VALUES (1,'2023-11-21T21:32:18.158083','https://youngcheline.s3.ap-northeast-2.amazonaws.com/2020305821_%EC%B9%98%EC%A6%88%EB%8F%88%EA%B9%8C%EC%8A%A4_%E1%84%83%E1%85%A1%E1%84%8B%E1%85%AE%E1%86%AB%E1%84%85%E1%85%A9%E1%84%83%E1%85%B3.jpeg'),(1,'2023-11-21T21:32:56.639873','https://youngcheline.s3.ap-northeast-2.amazonaws.com/2020305821_%EC%B9%98%EC%A6%88%EB%8F%88%EA%B9%8C%EC%8A%A4_%E1%84%83%E1%85%A1%E1%84%8B%E1%85%AE%E1%86%AB%E1%84%85%E1%85%A9%E1%84%83%E1%85%B3.jpeg'),(8,'2023-12-04T20:48:23.235938','https://youngcheline.s3.ap-northeast-2.amazonaws.com/2020305821_%EC%B9%98%EC%A6%88%EB%8F%88%EA%B9%8C%EC%8A%A4_%E1%84%83%E1%85%A1%E1%84%8B%E1%85%AE%E1%86%AB%E1%84%85%E1%85%A9%E1%84%83%E1%85%B3.jpeg'),(8,'2023-12-04T20:50:39.325735','https://youngcheline.s3.ap-northeast-2.amazonaws.com/2020305821_%EC%B9%98%EC%A6%88%EB%8F%88%EA%B9%8C%EC%8A%A4_%E1%84%83%E1%85%A1%E1%84%8B%E1%85%AE%E1%86%AB%E1%84%85%E1%85%A9%E1%84%83%E1%85%B3.jpeg'),(8,'2023-12-04T20:59:57.638092','https://youngcheline.s3.ap-northeast-2.amazonaws.com/2020305821_%EC%B9%98%EC%A6%88%EB%8F%88%EA%B9%8C%EC%8A%A4_%E1%84%83%E1%85%A1%E1%84%8B%E1%85%AE%E1%86%AB%E1%84%85%E1%85%A9%E1%84%83%E1%85%B3.jpeg'),(8,'2023-12-04T21:00:32.795713','https://youngcheline.s3.ap-northeast-2.amazonaws.com/2020305821_%EC%B9%98%EC%A6%88%EB%8F%88%EA%B9%8C%EC%8A%A4_%E1%84%83%E1%85%A1%E1%84%8B%E1%85%AE%E1%86%AB%E1%84%85%E1%85%A9%E1%84%83%E1%85%B3.jpeg'),(8,'2023-12-06T11:58:08.002693','https://youngcheline.s3.ap-northeast-2.amazonaws.com/8_8-thumbnail'),(8,'2023-12-06T12:25:04.214293','https://youngcheline.s3.ap-northeast-2.amazonaws.com/8_8-thumbnail'),(8,'2023-12-06T15:47:21.257930','https://youngcheline.s3.ap-northeast-2.amazonaws.com/8_8-thumbnail'),(25,'2023-12-04T21:02:29.689326','https://youngcheline.s3.ap-northeast-2.amazonaws.com/2020305821_%EC%B9%98%EC%A6%88%EB%8F%88%EA%B9%8C%EC%8A%A4_%E1%84%83%E1%85%A1%E1%84%8B%E1%85%AE%E1%86%AB%E1%84%85%E1%85%A9%E1%84%83%E1%85%B3.jpeg'),(26,'2023-12-05T18:56:37.413689','https://youngcheline.s3.ap-northeast-2.amazonaws.com/2020305821_%EC%B9%98%EC%A6%88%EB%8F%88%EA%B9%8C%EC%8A%A4_%E1%84%83%E1%85%A1%E1%84%8B%E1%85%AE%E1%86%AB%E1%84%85%E1%85%A9%E1%84%83%E1%85%B3.jpeg'),(26,'2023-12-05T18:57:05.611814','https://youngcheline.s3.ap-northeast-2.amazonaws.com/2020305821_%EC%B9%98%EC%A6%88%EB%8F%88%EA%B9%8C%EC%8A%A4_%E1%84%83%E1%85%A1%E1%84%8B%E1%85%AE%E1%86%AB%E1%84%85%E1%85%A9%E1%84%83%E1%85%B3.jpeg'),(35,'2023-12-05T21:29:21.759361','https://youngcheline.s3.ap-northeast-2.amazonaws.com/2020305821_%EC%B9%98%EC%A6%88%EB%8F%88%EA%B9%8C%EC%8A%A4_%E1%84%83%E1%85%A1%E1%84%8B%E1%85%AE%E1%86%AB%E1%84%85%E1%85%A9%E1%84%83%E1%85%B3.jpeg');
/*!40000 ALTER TABLE `menu_image` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2023-12-07 18:23:37
