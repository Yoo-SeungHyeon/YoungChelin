-- MySQL dump 10.13  Distrib 8.0.34, for Win64 (x86_64)
--
-- Host: 127.0.0.1    Database: young_cheline
-- ------------------------------------------------------
-- Server version	8.0.35

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `kakao_map`
--

DROP TABLE IF EXISTS `kakao_map`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `kakao_map` (
  `id` bigint NOT NULL,
  `place_name` varchar(255) DEFAULT NULL,
  `road_address_name` varchar(255) DEFAULT NULL,
  `x` varchar(255) DEFAULT NULL,
  `y` varchar(255) DEFAULT NULL,
  `restaurant_id` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `kakao_map`
--

LOCK TABLES `kakao_map` WRITE;
/*!40000 ALTER TABLE `kakao_map` DISABLE KEYS */;
INSERT INTO `kakao_map` VALUES (1,'몽짬뽕 경산점','경북 경산시 원효로42길 27-16','128.75812445142165','35.816766353151415','20638851'),(2,'백정육회','경북 경산시 둥지로10길 2','128.7531133','35.84204945','1258680088'),(3,'손시스시 본점','경북 경산시 대학로 325','128.75656645746332','35.83924517671622','27407049'),(4,'에이바이트키친','경북 경산시 청운로 1','128.7516166','35.83659245','27407036'),(5,'영남동','경북 경산시 대학로61길 24','128.7535444','35.83981108','444340519'),(6,'영대막창','경북 경산시 대학로 277','128.7525018','35.8363885','14541884'),(7,'오늘김해뒷고기 영남대점','경북 경산시 청운1로 28-3','128.7536934','35.83863834','1566612864'),(8,'맛있는오칠구 영남대점','경북 경산시 둥지로 2','128.7562269','35.83930421','434788818'),(9,'온어데일리','경북 경산시 청운로 12','128.7525049','35.83672728','226916996'),(10,'용용선생 영남대점','경북 경산시 대학로59길 14','128.753347','35.83833701','143343585'),(11,'유비칼국수','경북 경산시 압량읍 압독2로2길 23','128.7629749','35.84097878','880781940'),(12,'청춘양식당 영대점','경북 경산시 청운로 25-1','128.7535106','35.83777232','746623517'),(13,'카츠D9디나인','경북 경산시 청운로 5','128.751965','35.83673515','2020305821'),(14,'타이짬뽕 사동점','경북 경산시 원효로 180','128.7559495','35.81948712','26353366'),(15,'해피치즈스마일 영남대점','경북 경산시 청운1로 24','128.752935','35.8383223','1032781993'),(16,'홍대함바그','경북 경산시 청운로 13-1','128.7525015','35.83717789','1323716207'),(17,'후라이드참잘하는집 영남대점','경북 경산시 대학로61길 12-3','128.75416190828508','35.83930824427001','277055458'),(18,'해쉬','경북 경산시 대동안길 19','128.7523348','35.83845631','1956466361'),(19,'자야','경북 경산시 청운로 23-1','128.7532172','35.83771893','983114429'),(20,'장군찜닭','경북 경산시 청운1로 6-1','128.75154810759466','35.83750538228979','11300334'),(21,'88식당','경북 경산시 대학로53길 12-3','128.7515081385601','35.837096854368625','1883770159'),(22,'가보뚝배기24시감자탕','경북 경산시 청운로 15','128.752855','35.8371511','15752650'),(23,'고기듬뿍대왕비빔밥 영대점','경북 경산시 대학로70길 31','128.7593789','35.83790821','714569417'),(24,'길가네국밥','경북 경산시 압량읍 대학로69길 2','128.7580115','35.84033422','11385265'),(25,'꽃뚜껑 영대점','경북 경산시 대학로59길 11-1','128.7533791','35.83793194','287757696'),(26,'돈까스에빠지다 경산영대점','경북 경산시 청운로 29','128.7540036','35.83805168','392495073'),(27,'돈우리','경북 경산시 청운로 37','128.7546431','35.83854517','10306127'),(28,'동궁찜닭 영대점','경북 경산시 대학로53길 12-6','128.7516946','35.83702114','777963780'),(29,'록키맥주','경북 경산시 청운1로 11','128.7518842','35.83789337','2084958402'),(30,'1058면','경북 경산시 청운로 11','128.7524648','35.8369189','86660948');
/*!40000 ALTER TABLE `kakao_map` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2023-12-07 18:23:37
